# CityFlow Frontend Tool

Open `index.html` to view replay.

Run `python download_replay.py` to download example replay files.

Checkout [Document](https://cityflow.readthedocs.io/en/latest/replay.html) for more instructions.