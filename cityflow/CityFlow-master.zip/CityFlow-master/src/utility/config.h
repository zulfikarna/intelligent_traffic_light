#ifndef CITYFLOW_CONFIG_H
#define CITYFLOW_CONFIG_H

namespace CityFlow {
    const int MAX_NUM_CARS_ON_SEGMENT = 10;
}

#endif //CITYFLOW_CONFIG_H
